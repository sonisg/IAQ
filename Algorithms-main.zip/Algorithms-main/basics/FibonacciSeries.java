package com.company.basics;

public class FibonacciSeries {


    public static void main(String args[])
    {
        int n = 15;
        FibonacciFunction fib = new FibonacciFunction();
        //fib.fib(n);
        fib.fibonacci(n);
    }
}
